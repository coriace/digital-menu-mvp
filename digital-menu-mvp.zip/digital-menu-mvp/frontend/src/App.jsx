
import { Link } from 'react-router-dom'

export default function App() {
  return (
    <div style={{fontFamily:'system-ui, sans-serif', padding:'24px', maxWidth:900, margin:'0 auto'}}>
      <h1>🍽️ Menu Digital – MVP</h1>
      <p>Créez un menu digital, générez un QR code, et partagez-le avec vos clients.</p>
      <div style={{display:'flex', gap:12, marginTop:16}}>
        <Link to="/admin" style={{padding:'10px 16px', border:'1px solid #333', borderRadius:8, textDecoration:'none'}}>Accès Admin</Link>
        <a href="https://github.com/" target="_blank" rel="noreferrer" style={{padding:'10px 16px', border:'1px solid #aaa', borderRadius:8, textDecoration:'none'}}>Doc (à venir)</a>
      </div>
      <p style={{marginTop:24, color:'#666'}}>Astuce : commencez par créer votre restaurant depuis l’Admin.</p>
    </div>
  )
}
