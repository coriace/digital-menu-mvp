
import { useEffect, useState } from 'react'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:3000'

export default function Admin() {
  const [name, setName] = useState('Mon Restaurant')
  const [slug, setSlug] = useState('mon-restaurant')
  const [languages, setLanguages] = useState('fr,en')
  const [items, setItems] = useState([])

  // item form
  const [item, setItem] = useState({ name:'', description:'', price:0, category:'Plats', tags:'', available:true, image:'' })

  useEffect(() => {
    if (slug) refreshItems(slug)
  }, [slug])

  async function refreshItems(s) {
    try {
      const { data } = await axios.get(`${API}/api/items`, { params: { slug: s } })
      setItems(data)
    } catch (e) {
      console.error(e)
    }
  }

  async function saveRestaurant() {
    try {
      await axios.post(`${API}/api/restaurants`, { name, slug, languages: languages.split(',').map(s=>s.trim()).filter(Boolean) })
      alert('Restaurant enregistré ✅')
      refreshItems(slug)
    } catch (e) {
      alert('Erreur enregistrement restaurant')
    }
  }

  async function addItem() {
    if (!item.name) return alert('Nom du plat obligatoire')
    try {
      const payload = { ...item, slug, tags: item.tags? item.tags.split(',').map(t=>t.trim()).filter(Boolean) : [] }
      const { data } = await axios.post(`${API}/api/items`, payload)
      setItems(prev => [data, ...prev])
      setItem({ name:'', description:'', price:0, category:'Plats', tags:'', available:true, image:'' })
    } catch (e) {
      alert('Erreur ajout plat')
    }
  }

  async function toggleAvailability(id, available) {
    try {
      const { data } = await axios.patch(`${API}/api/items/${id}`, { available: !available })
      setItems(prev => prev.map(i => i.id === id ? data : i))
    } catch (e) {
      console.error(e)
    }
  }

  async function removeItem(id) {
    if (!confirm('Supprimer cet élément ?')) return
    try {
      await axios.delete(`${API}/api/items/${id}`)
      setItems(prev => prev.filter(i => i.id !== id))
    } catch (e) {
      console.error(e)
    }
  }

  return (
    <div style={{fontFamily:'system-ui, sans-serif', padding:'24px', maxWidth:1100, margin:'0 auto'}}>
      <h1>Admin – Menu Digital</h1>

      <section style={{border:'1px solid #ddd', padding:16, borderRadius:12, marginTop:12}}>
        <h2>🛠️ Paramètres du restaurant</h2>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
          <label>Nom<br/>
            <input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%'}}/>
          </label>
          <label>Slug (url)<br/>
            <input value={slug} onChange={e=>setSlug(e.target.value)} style={{width:'100%'}}/>
          </label>
          <label>Langues (ex: fr,en)<br/>
            <input value={languages} onChange={e=>setLanguages(e.target.value)} style={{width:'100%'}}/>
          </label>
        </div>
        <div style={{display:'flex', gap:8, marginTop:12}}>
          <button onClick={saveRestaurant}>Enregistrer</button>
          <a href={`/menu/${encodeURIComponent(slug)}`} target="_blank">Voir le menu public</a>
          <a href={`${API}/api/qr/${encodeURIComponent(slug)}`} target="_blank">Télécharger le QR</a>
        </div>
      </section>

      <section style={{border:'1px solid #ddd', padding:16, borderRadius:12, marginTop:12}}>
        <h2>🍲 Ajouter un élément</h2>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
          <label>Nom<br/><input value={item.name} onChange={e=>setItem({...item, name:e.target.value})} style={{width:'100%'}}/></label>
          <label>Prix (ex: 89.9)<br/><input type="number" step="0.01" value={item.price} onChange={e=>setItem({...item, price:parseFloat(e.target.value || '0')})} style={{width:'100%'}}/></label>
          <label>Catégorie<br/><input value={item.category} onChange={e=>setItem({...item, category:e.target.value})} style={{width:'100%'}}/></label>
          <label>Tags (ex: vegan,épice)<br/><input value={item.tags} onChange={e=>setItem({...item, tags:e.target.value})} style={{width:'100%'}}/></label>
          <label>Description<br/><textarea value={item.description} onChange={e=>setItem({...item, description:e.target.value})} style={{width:'100%'}}/></label>
          <label>Image (URL, optionnel)<br/><input value={item.image} onChange={e=>setItem({...item, image:e.target.value})} style={{width:'100%'}}/></label>
        </div>
        <div style={{marginTop:12}}>
          <label><input type="checkbox" checked={item.available} onChange={e=>setItem({...item, available:e.target.checked})}/> Disponible</label>
        </div>
        <button style={{marginTop:12}} onClick={addItem}>Ajouter</button>
      </section>

      <section style={{border:'1px solid #ddd', padding:16, borderRadius:12, marginTop:12}}>
        <h2>📋 Éléments ({items.length})</h2>
        <div style={{display:'grid', gap:8}}>
          {items.map(i => (
            <div key={i.id} style={{display:'grid', gridTemplateColumns:'80px 1fr auto', gap:12, alignItems:'center', border:'1px solid #eee', padding:8, borderRadius:8}}>
              <div>{i.image ? <img src={i.image} alt="" style={{width:80, height:80, objectFit:'cover', borderRadius:8}}/> : <div style={{width:80, height:80, background:'#f2f2f2', borderRadius:8}}/>}</div>
              <div>
                <strong>{i.name}</strong> — {i.category} — {i.price.toFixed(2)} MAD
                <div style={{color:'#666', fontSize:14}}>{i.description}</div>
                <div style={{fontSize:12, color:'#888'}}>Tags: {(i.tags||[]).join(', ')}</div>
              </div>
              <div style={{display:'flex', gap:8}}>
                <button onClick={()=>toggleAvailability(i.id, i.available)}>{i.available? 'Masquer' : 'Afficher'}</button>
                <button onClick={()=>removeItem(i.id)} style={{color:'#b00'}}>Supprimer</button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
