
import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import axios from 'axios'

const API = import.meta.env.VITE_API_BASE || 'http://localhost:3000'

export default function PublicMenu() {
  const { slug } = useParams()
  const [data, setData] = useState(null)
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState('')

  useEffect(() => {
    axios.get(`${API}/api/menu/${slug}`).then(({data}) => setData(data)).catch(()=>setData({error:true}))
  }, [slug])

  if (!data) return <div style={{fontFamily:'system-ui, sans-serif', padding:24}}>Chargement…</div>
  if (data.error) return <div style={{fontFamily:'system-ui, sans-serif', padding:24}}>Menu introuvable.</div>

  const categories = Object.keys(data.categories || {})
  const items = categories.flatMap(cat => data.categories[cat].map(it => ({...it, _cat:cat})))
  const filtered = items.filter(it => 
    (!filter || it._cat === filter) &&
    (!q || `${it.name} ${it.description} ${it._cat} ${(it.tags||[]).join(' ')}`.toLowerCase().includes(q.toLowerCase()))
  )

  return (
    <div style={{fontFamily:'system-ui, sans-serif', padding:'16px 24px', maxWidth:900, margin:'0 auto'}}>
      <header style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:12}}>
        <h1>{data.restaurant?.name}</h1>
        <img src={`${API}/api/qr/${slug}`} alt="QR" style={{width:80, height:80}}/>
      </header>

      <div style={{display:'flex', gap:8, marginTop:8}}>
        <input placeholder="Recherche…" value={q} onChange={e=>setQ(e.target.value)} style={{flex:1}}/>
        <select value={filter} onChange={e=>setFilter(e.target.value)}>
          <option value="">Toutes les catégories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div style={{display:'grid', gap:12, marginTop:12}}>
        {filtered.map(it => (
          <div key={it.id} style={{display:'grid', gridTemplateColumns:'80px 1fr auto', gap:12, alignItems:'center', border:'1px solid #eee', padding:8, borderRadius:8}}>
            <div>{it.image ? <img src={it.image} alt="" style={{width:80, height:80, objectFit:'cover', borderRadius:8}}/> : <div style={{width:80, height:80, background:'#f2f2f2', borderRadius:8}}/>}</div>
            <div>
              <div style={{display:'flex', justifyContent:'space-between'}}>
                <strong>{it.name}</strong>
                <span>{it.price.toFixed(2)} MAD</span>
              </div>
              <div style={{color:'#666', fontSize:14}}>{it.description}</div>
              <div style={{fontSize:12, color:'#888'}}>{it._cat}</div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div style={{color:'#666'}}>Aucun élément ne correspond à la recherche.</div>}
      </div>

      <footer style={{marginTop:24, fontSize:12, color:'#888'}}>
        Propulsé par Menu Digital – MVP
      </footer>
    </div>
  )
}
