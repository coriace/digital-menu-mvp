
# Digital Menu – Frontend (React + Vite)

## Setup
```bash
cd frontend
npm install
npm run dev
```
By default it runs on http://localhost:5173

Create a `.env` file (optional):
```
VITE_API_BASE=http://localhost:3000
```
