
import express from "express";
import cors from "cors";
import { Low } from "lowdb";
import { JSONFile } from "lowdb/node";
import { customAlphabet } from "nanoid";
import QRCode from "qrcode";

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND_BASE = process.env.FRONTEND_BASE || "http://localhost:5173";

app.use(cors());
app.use(express.json({ limit: "2mb" }));

// Setup DB
const adapter = new JSONFile("./db.json");
const db = new Low(adapter, { restaurants: [], items: [] });
await db.read();
db.data ||= { restaurants: [], items: [] };
await db.write();

const nanoid = customAlphabet("1234567890abcdefghijklmnopqrstuvwxyz", 10);

// Utils
const findRestaurantBySlug = (slug) => db.data.restaurants.find(r => r.slug === slug);

// Routes
app.get("/", (_, res) => res.json({ status: "ok", service: "Digital Menu API" }));

// Create/Update restaurant
app.post("/api/restaurants", async (req, res) => {
  const { name, slug, languages = ["fr"] } = req.body;
  if (!name || !slug) return res.status(400).json({ error: "name and slug are required" });
  const exists = findRestaurantBySlug(slug);
  if (exists) {
    exists.name = name;
    exists.languages = languages;
  } else {
    db.data.restaurants.push({ id: nanoid(), name, slug, languages });
  }
  await db.write();
  res.json({ ok: true });
});

app.get("/api/restaurants/:slug", (req, res) => {
  const r = findRestaurantBySlug(req.params.slug);
  if (!r) return res.status(404).json({ error: "restaurant not found" });
  res.json(r);
});

// Items CRUD
app.post("/api/items", async (req, res) => {
  const { slug, name, description = "", price = 0, category = "Divers", tags = [], available = true, image = "" } = req.body;
  if (!slug || !name) return res.status(400).json({ error: "slug and name required" });
  const r = findRestaurantBySlug(slug);
  if (!r) return res.status(404).json({ error: "restaurant not found" });
  const item = { id: nanoid(), slug, name, description, price, category, tags, available, image };
  db.data.items.push(item);
  await db.write();
  res.json(item);
});

app.get("/api/items", (req, res) => {
  const { slug } = req.query;
  if (!slug) return res.status(400).json({ error: "slug required" });
  res.json(db.data.items.filter(i => i.slug === slug));
});

app.patch("/api/items/:id", async (req, res) => {
  const item = db.data.items.find(i => i.id === req.params.id);
  if (!item) return res.status(404).json({ error: "item not found" });
  Object.assign(item, req.body || {});
  await db.write();
  res.json(item);
});

app.delete("/api/items/:id", async (req, res) => {
  const idx = db.data.items.findIndex(i => i.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "item not found" });
  db.data.items.splice(idx, 1);
  await db.write();
  res.json({ ok: true });
});

// Public menu
app.get("/api/menu/:slug", (req, res) => {
  const r = findRestaurantBySlug(req.params.slug);
  if (!r) return res.status(404).json({ error: "restaurant not found" });
  const items = db.data.items.filter(i => i.slug === r.slug && i.available);
  // group by category
  const grouped = items.reduce((acc, it) => {
    acc[it.category] = acc[it.category] || [];
    acc[it.category].push(it);
    return acc;
  }, {});
  res.json({ restaurant: r, categories: grouped });
});

// QR code endpoint
app.get("/api/qr/:slug", async (req, res) => {
  const slug = req.params.slug;
  const r = findRestaurantBySlug(slug);
  if (!r) return res.status(404).json({ error: "restaurant not found" });
  const url = `${FRONTEND_BASE}/menu/${encodeURIComponent(slug)}`;
  try {
    const pngBuffer = await QRCode.toBuffer(url, { type: "png", width: 512, margin: 1 });
    res.setHeader("Content-Type", "image/png");
    res.send(pngBuffer);
  } catch (e) {
    res.status(500).json({ error: "qr_failed", details: String(e) });
  }
});

app.listen(PORT, () => {
  console.log(`API running on http://localhost:${PORT}`);
});
