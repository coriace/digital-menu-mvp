
# Digital Menu – Backend (Express + LowDB)

## Setup
```bash
cd backend
npm install
npm run start
```
By default it runs on http://localhost:3000

### Environment (optional)
- `PORT=3000`
- `FRONTEND_BASE=http://localhost:5173`  # used to embed in the QR destination

## API
- `POST /api/restaurants` { name, slug, languages }
- `GET /api/restaurants/:slug`
- `POST /api/items` { slug, name, description, price, category, tags[], available, image }
- `GET /api/items?slug=...`
- `PATCH /api/items/:id` (partial update)
- `DELETE /api/items/:id`
- `GET /api/menu/:slug` (public grouped menu)
- `GET /api/qr/:slug` -> PNG image of QR that points to the public menu URL

Data is stored in `db.json` (LowDB).
